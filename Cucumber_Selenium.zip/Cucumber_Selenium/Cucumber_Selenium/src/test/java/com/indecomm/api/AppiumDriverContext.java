/**
 * 
 */
package com.indecomm.api;

import java.io.File;
import java.io.FileReader;

/**
 * @author navjotkochar
 */

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.ContainerFactory;
import org.json.simple.parser.JSONParser;
import org.openqa.selenium.remote.DesiredCapabilities;

import com.mongodb.util.JSON;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.IOSMobileCapabilityType;

public class AppiumDriverContext {
	// public static IOSDriverContext driverContext;
	public static AppiumDriver driver;
	static JSONParser parser = new JSONParser();

	public static AppiumDriver getDriver(String device, String OSwithDevice) throws IOException {
		org.json.simple.JSONObject jsonObject = null;
		org.json.simple.JSONObject jsonObject1 = null;
		org.json.simple.JSONObject jsonObject2 = null;
		try {

			String cwd = System.getProperty("user.dir") + "/feedFiles/DeviceCababilities.json";
			Object obj = parser.parse(new FileReader(cwd));
			jsonObject = (JSONObject) obj;
			// System.out.println(cwd);
			jsonObject1 = (JSONObject) jsonObject.get(OSwithDevice);
			System.out.println(jsonObject1);
			jsonObject2 = (JSONObject) jsonObject1.get("capabilities");

		} catch (Exception e) {
			e.printStackTrace();
		}

		if (device.equalsIgnoreCase("Android")) {

			if (driver == null) {

				DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
				desiredCapabilities.setCapability("platformName", jsonObject2.get("platformName").toString());
				desiredCapabilities.setCapability("platformVersion", jsonObject2.get("version").toString());
				desiredCapabilities.setCapability("deviceName", jsonObject2.get("device").toString());
				desiredCapabilities.setCapability("appWaitActivity",
						"SplashActivity, SplashActivity,OtherActivity, *, *.SplashActivity");
				desiredCapabilities.setCapability("app", jsonObject2.get("app").toString());
				// desiredCapabilities.setCapability("appPackage",
				// jsonObject2.get("app_package").toString());
				// desiredCapabilities.setCapability("appActivity",
				// jsonObject2.get("activity").toString());
				driver = new AppiumDriver(new URL(jsonObject2.get("appiumServer").toString()), desiredCapabilities);
				driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
			}
		} else if (device.equalsIgnoreCase("iOS")) {
			DesiredCapabilities desiredCapabilities = new DesiredCapabilities();
			desiredCapabilities.setCapability("platformName", jsonObject2.get("platformName").toString());
			desiredCapabilities.setCapability("platformVersion", jsonObject2.get("version").toString());
			desiredCapabilities.setCapability("deviceName", jsonObject2.get("device").toString());

			desiredCapabilities.setCapability(IOSMobileCapabilityType.BUNDLE_ID,
					jsonObject2.get("bundleid").toString());

			//desiredCapabilities.setCapability("deviceName", jsonObject2.get("device").toString());
			desiredCapabilities.setCapability("udid", jsonObject2.get("deviceudid").toString());
			//desiredCapabilities.setCapability("automationName", "XCUITest");
			desiredCapabilities.setCapability("appPackage", jsonObject2.get("app_package").toString());
			desiredCapabilities.setCapability("appActivity", jsonObject2.get("activity").toString());
			driver = new IOSDriver(new URL(jsonObject2.get("appiumServer").toString()), desiredCapabilities);
			driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		}
		return driver;

	}

	public static void closeDriver() {
		if (null != driver) {
			// driver.resetApp();
			driver.closeApp();
			driver.launchApp();
			// driver = null;
		}
	}

}